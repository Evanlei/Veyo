Veyo predictions are spatial model probabilities, not CTR, sales, or measured human attention.
